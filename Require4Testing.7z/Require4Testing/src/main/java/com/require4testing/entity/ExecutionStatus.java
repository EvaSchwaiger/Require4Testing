package com.require4testing.entity;

public enum ExecutionStatus {
    ASSIGNED, PASSED, FAILED, BLOCKED
}